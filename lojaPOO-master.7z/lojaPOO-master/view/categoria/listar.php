        <nav class="navbar navbar-default">
            <div class="navbar-header">
                <a class="navbar-brand">Lista de Categorias</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="index.php?acao=incluir">Nova Categoria</a></li>
            </ul>
        </nav>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>&#45;</th>
                </tr>
            </thead>
            <tbody>
            <?php
                $categorias = $dados['categorias'];

                    foreach($categorias as $categoria){
                        echo '<tr>';
                        echo '<td>'.$categoria->getId().'</td>';
                        echo '<td>'.utf8_encode($categoria->getNome()).'</td>';
                        echo '<td>'.utf8_encode($categoria->getDescricao()).'</td>';
                        echo '<td><a href="index.php?acao=detalhes&id='.$categoria->getId().'">Detalhes</a></td>';
                        echo '</tr>';
                    }
            ?>
            </tbody>
        </table>