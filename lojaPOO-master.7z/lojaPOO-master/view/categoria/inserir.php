<form action="">
    
    nome <input type="text" name="nome">
    descricao <input type="text" name="descricao">
    <input type="submit">
</form>