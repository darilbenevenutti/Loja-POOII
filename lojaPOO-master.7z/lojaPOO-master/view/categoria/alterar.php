<?php
    //capturo o objeto categoria que foi passado em $dados
    $categoria = $dados['categorias'][0];
?>
    <nav class="navbar navbar-default">
        <div class="navbar-header">
            <a class="navbar-brand">Alterar dados da Categoria</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="index.php?acao=incluir">Nova Categoria</a></li>
            <li><a href="index.php?acao=excluir&id=<?= $categoria->getId() ?>">Excluir Categoria</a></li>
            <li><a href="index.php?acao=index">Voltar para a lista</a></li>
        </ul>
    </nav>

    <form method="post" action="index.php?acao=gravaalterar">
        <input type="hidden" name="id" value="<?= $categoria->getId() ?>">
        
        <div class="form-group">
            <label for="nome">Nome</label>
            <input type="text" class="form-control" id="nome" name="nome" maxlength="60" value="<?= utf8_encode($categoria->getNome()) ?>" placeholder="Nome da categoria" required>
        </div>
        <div class="form-group">
            <label for="descricao">Descrição</label>
            <input type="text" class="form-control" id="descricao" name="descricao" maxlength="255" value="<?= utf8_encode($categoria->getDescricao()) ?>" placeholder="Descrição da categoria" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>