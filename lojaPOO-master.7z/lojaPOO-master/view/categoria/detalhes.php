<?php
    //capturo o objeto categoria que foi passado em $dados
    $categoria = $dados['categorias'][0];
?>

    <nav class="navbar navbar-default">
        <div class="navbar-header">
            <a class="navbar-brand">Detalhes da Categoria</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="index.php?acao=incluir">Nova Categoria</a></li>
            <li><a href="index.php?acao=alterar&id=<?=$categoria->getId() ?>">Alterar Categoria</a></li>
            <li><a href="index.php?acao=excluir&id=<?= $categoria->getId() ?>">Excluir Categoria</a></li>
            <li><a href="index.php?acao=index">Voltar para a lista</a></li>
        </ul>
    </nav>
    <table class="table">
        <tr><td>ID</td><td><?= $categoria->getId() ?></td></tr>
        <tr><td>Nome</td><td><?= utf8_encode($categoria->getNome()) ?></td></tr>
        <tr><td>Descrição</td><td><?= utf8_encode($categoria->getDescricao()) ?></td></tr>
    </table>